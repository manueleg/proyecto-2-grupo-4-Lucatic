package com.spring.model;

public enum Genero {
	H,
	M;
}
